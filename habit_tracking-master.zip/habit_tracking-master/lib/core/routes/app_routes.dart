abstract class AppRoutes {
  static const splash = '/';
  static const home = '/home';
  static const timer = '/timer';
  static const login = '/login';

  // static const main = '/navigation';

  static const newHabitView = '/newHabitView';

}