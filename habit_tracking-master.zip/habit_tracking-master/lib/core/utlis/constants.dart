
const kHabitsBox = "habits_box";