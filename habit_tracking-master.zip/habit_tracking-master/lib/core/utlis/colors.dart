import 'package:flutter/material.dart';

class TColors{
  TColors._();

  static const Color PrimaryColor01 = Color(0xff5F6CE2);
  static const Color PrimaryColor02 = Color(0xff2F3138);
  static const Color PrimaryColor03 = Color(0xff7C84A3);
  static const Color PrimaryColor04 = Color(0xffE1EDFB);
  static const Color PrimaryColor05 = Color(0xffFFFFFF);
  static const Color PrimaryColor06 = Color(0xffF8F8F8);
  static const Color ColorPlaceHolder = Color(0xffABAEBA);
}