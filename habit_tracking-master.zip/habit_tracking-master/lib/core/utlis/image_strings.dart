// this class contains all the app images in String formats.
class TImages {

  //App on boarding images and starting
  static const String onBoardingImage1 = 'assets/images/onboarding01.png';
  static const String onBoardingImage2 = 'assets/images/onboarding02.png';
  static const String onBoardingImage3 = 'assets/images/onboarding03.png';
  static const String startingImage = 'assets/images/starting.png';

  //App logos
  static const String lightAppLogo = "assets/logo/logos.png";

  //Social logos


}