class ItemModel{
  String title,image,subTitle,totalTime;
   int color;

  ItemModel({required this.title,required this.subTitle,required this.image,required this.totalTime, required this.color});


}