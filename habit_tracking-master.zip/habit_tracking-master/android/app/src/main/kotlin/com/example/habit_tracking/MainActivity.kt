package com.example.habit_tracking

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
